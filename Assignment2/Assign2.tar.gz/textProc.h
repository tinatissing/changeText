int chop ( char *line );
int convertLowerCase ( char *line );
int replaceDigits ( char *line );
int replacePunc ( char *line );
int reduceSpace ( char *line );
int trim ( char *line );
